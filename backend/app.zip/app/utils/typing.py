﻿from typing import Dict, Any
StrDict = Dict[str, Any]
